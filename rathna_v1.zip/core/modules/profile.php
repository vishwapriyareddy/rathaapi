<?php
require_once('../db/config.php');

function AdminProfile($admin_id){
    
    $db = get_config();    
    $getAdmin = $db->prepare("SELECT * FROM admin WHERE admin_id=:admin_id");
    $getAdmin->execute(['admin_id' => $admin_id]); 
    $admin = $getAdmin->fetch();
    return $admin;
}